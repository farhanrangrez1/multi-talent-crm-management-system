import React, { useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import { FiSearch } from "react-icons/fi";
import { IoMdNotificationsOutline } from "react-icons/io";
import { IoMailOutline } from "react-icons/io5";
import { FaThLarge, FaUsers, FaCreditCard, FaTags, FaGlobe, FaReceipt, FaChartBar, FaCog, FaChevronDown, FaChevronUp } from "react-icons/fa";
import { MdOutlineAdminPanelSettings } from "react-icons/md";

const navLinks = [
  { icon: <FaThLarge />, label: "Dashboard" },
  {
    icon: <FaUsers />, label: "User Management", expandable: true, subItems: [
      { label: "All Users" ,   path: "/allUsers",},
      { label: "Buyers" },
      { label: "Sellers" },
    ]
  },
  {
    icon: <FaCreditCard />, label: "Subscription Plans", expandable: true, subItems: [
      { label: "All Plans" },
      { label: "Add Plan" },
    ]
  },
  { icon: <FaTags />, label: "Coupons" },
  { icon: <FaGlobe />, label: "Domain Control" },
  { icon: <FaReceipt />, label: "Payment Logs" },
  { icon: <FaChartBar />, label: "Reports & Analytics" },
  { icon: <FaCog />, label: "Admin Settings" },
];

function Nevbar({ onSidebarToggle }) {
  const [active, setActive] = useState("Dashboard");
  const [expanded, setExpanded] = useState({});
  // State for calendar (date range selector)
  const [startDate, setStartDate] = useState(new Date());
  // Message dropdown state
  const [showMessages, setShowMessages] = useState(false);

  // For closing dropdown on outside click
  React.useEffect(() => {
    function handleClickOutside(event) {
      if (!event.target.closest('.message-dropdown') && !event.target.closest('.message-icon-btn')) {
        setShowMessages(false);
      }
    }
    if (showMessages) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showMessages]);

  const handleNavClick = (label, expandable) => {
    setActive(label);
    if (expandable) {
      setExpanded(prev => ({ ...prev, [label]: !prev[label] }));
    }
  };

  // Color palette
  const sidebarBg = '#f9fafb';
  const activeBg = '#4f46e5';
  const activeText = '#fff';
  const activeIcon = '#fff';
  const inactiveText = '#334155';
  const inactiveIcon = '#334155';
  const hoverBg = '#f1f5f9';
  const borderColor = '#e5e7eb';
  const activeBorder = '#6366f1';
  const dividerColor = '#e2e8f0';

  return (
    <div>
        {/* Top Navbar */}
        <nav className="navbar navbar-expand-lg navbar-light bg-white border-bottom px-4 py-3" style={{ fontFamily: 'Inter, sans-serif', minHeight: 72 }}>
          <div className="container-fluid">
            {/* Hamburger for mobile */}
            <button className="btn d-lg-none me-2" type="button" onClick={onSidebarToggle} aria-label="Toggle sidebar">
              <span style={{ fontSize: 24 }}>&#9776;</span>
            </button>
            <span className="navbar-brand fw-bold" style={{ fontSize: 20, color: '#222' }}>Admin Dashboard</span>
            <div className="d-flex align-items-center ms-auto gap-3">
              {/* Search Icon */}
              <button className="btn btn-link p-0" style={{ color: '#94a3b8', fontSize: 22 }}>
                <FiSearch />
              </button>
              {/* Notification Icon */}
              <div className="position-relative">
                <button className="btn btn-link p-0" style={{ color: '#94a3b8', fontSize: 24 }}>
                  <IoMdNotificationsOutline />
                </button>
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style={{ fontSize: 11, padding: '2px 4px', top: 2 }}>3</span>
              </div>
              {/* Message Icon */}
              <div className="position-relative">
                <button
                  className="btn btn-link p-0 message-icon-btn"
                  style={{ color: '#94a3b8', fontSize: 22 ,}}
                  onClick={() => setShowMessages((prev) => !prev)}
                  aria-label="Show messages"
                  type="button"
                >
                  <IoMailOutline />
                </button>
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary" style={{ fontSize: 11, padding: '2px 4px', top: 2 }}>7</span>
                {/* Message Dropdown */}
                {showMessages && (
                  <div className="message-dropdown" style={{
                    position: 'absolute',
                    top: '160%', // slightly below the icon
                    right: 0,
                    minWidth: 270,
                    background: '#fff', // white background
                    color: '#222', // dark text
                    borderRadius: 10,
                    boxShadow: '0 4px 24px rgba(0,0,0,0.10)',
                    zIndex: 1000,
                    padding: 0,
                    border: '1px solid #e5e7eb',
                  }}>
                    <div style={{ padding: '12px 16px', borderBottom: '1px solid #f1f5f9', fontWeight: 600, fontSize: 15, color: '#222' }}>Messages</div>
                    <div style={{ padding: '12px 16px', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <img src="/vite.svg" alt="profile" style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }} />
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 14, color: '#222' }}>Mark send you a message</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>1 Minutes ago</div>
                      </div>
                    </div>
                    <div style={{ padding: '12px 16px', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <img src="/vite.svg" alt="profile" style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }} />
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 14, color: '#222' }}>Cregh send you a message</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>15 Minutes ago</div>
                      </div>
                    </div>
                    <div style={{ padding: '12px 16px', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <img src="/vite.svg" alt="profile" style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }} />
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 14, color: '#222' }}>Profile picture updated</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>18 Minutes ago</div>
                      </div>
                    </div>
                    <div style={{ padding: '12px 16px', textAlign: 'center', color: '#64748b', fontSize: 13 }}>
                      4 new messages
                    </div>
                  </div>
                )}
              </div>
              {/* User Info */}
              <div className="d-flex align-items-center gap-2 ms-2">
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 600, fontSize: 15, color: '#222' }}>Admin User</div>
                  <div className="text-muted small" style={{ fontSize: 13 }}>System Administrator</div>
                </div>
                <div style={{ width: 36, height: 36, background: '#6366f1', color: '#fff', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: 18, marginLeft: 6 }}>
                  A
                </div>
              </div>
            </div>
          </div>
        </nav>

    </div>
  );
}

export default Nevbar;