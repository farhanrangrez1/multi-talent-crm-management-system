import React from 'react'

function Sellers() {
  return (
    <div>Sellers</div>
  )
}

export default Sellers